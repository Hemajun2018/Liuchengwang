/**
 * 该文件用于兼容旧的引用路径，实际实现来自 modules/users/entities/user.entity.ts
 */
export { User, UserRole } from '../../modules/users/entities/user.entity'; 